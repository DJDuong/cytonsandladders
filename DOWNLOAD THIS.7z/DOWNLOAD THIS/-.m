    %Cage
    [fCage,vCage,dataCage] = plyread('environment/Cage5.ply','tri');
    vertexColours = [dataCage.vertex.red, dataCage.vertex.green, dataCage.vertex.blue] / 255;
    cage = trisurf(fCage,vCage(:,1)+ 0,vCage(:,2) + 0, vCage(:,3) - 0.01,...
       'FaceVertexCData',vertexColours,'EdgeColor','interp','EdgeLighting','flat');
    %Board
    [fBoard,vBoard,dataBoard] = plyread('environment/Board2.ply','tri');      
    vertexColours = [dataBoard.vertex.red, dataBoard.vertex.green, dataBoard.vertex.blue] / 255;
    board = trisurf(fBoard,vBoard(:,1)+0,vBoard(:,2) + 0.3, vBoard(:,3) + 0,...
       'FaceVertexCData',vertexColours,'EdgeColor','interp','EdgeLighting','flat');
    %Button
    [fButton,vButton,dataButton] = plyread('environment/button.ply','tri');      
    vertexColours = [dataButton.vertex.red, dataButton.vertex.green, dataButton.vertex.blue] / 255;
    button = trisurf(fButton,vButton(:,1)+0.6,vButton(:,2)+0.65, vButton(:,3)+0.2,...
       'FaceVertexCData',vertexColours,'EdgeColor','interp','EdgeLighting','flat');
    %UR3 Jig Plate
    [fPlate,vPlate,dataPlate] = plyread('environment/ur3 jig plate.ply','tri');      
    vertexColours = [dataPlate.vertex.red, dataPlate.vertex.green, dataPlate.vertex.blue] / 255;
    ur3 = trisurf(fPlate,vPlate(:,1)+0,vPlate(:,2)+0, vPlate(:,3)+0,...
       'FaceVertexCData',vertexColours,'EdgeColor','interp','EdgeLighting','flat');
    %Cyton Base
    [fCytonBase,vCytonBase,dataCytonBase] = plyread('environment/cytonbase.ply','tri');      
    vertexColours = [dataCytonBase.vertex.red, dataCytonBase.vertex.green, dataCytonBase.vertex.blue] / 255;
    cytonbase = trisurf(fCytonBase,vCytonBase(:,1)+0,vCytonBase(:,2)+0, vCytonBase(:,3)+0.01,...
       'FaceVertexCData',vertexColours,'EdgeColor','interp','EdgeLighting','flat');
    %Robot Base
    [fRobotBase,vRobotBase,dataRobotBase] = plyread('environment/RobotBase.ply','tri');      
    vertexColours = [dataRobotBase.vertex.red, dataRobotBase.vertex.green, dataRobotBase.vertex.blue] / 255;
    robotbase = trisurf(fRobotBase,vRobotBase(:,1)+0,vRobotBase(:,2)+0, vRobotBase(:,3)+0.016,...
       'FaceVertexCData',vertexColours,'EdgeColor','interp','EdgeLighting','flat');   
   
    fTotal = {fCage}; 
    vTotal = {vCage};
    fTotal{end+1} = fBoard; 
    vTotal{end+1} = vBoard;
    fTotal{end+1} = fButton; 
    vTotal{end+1} = vButton;
    fTotal{end+1} = fPlate; 
    vTotal{end+1} = vPlate;
    fTotal{end+1} = fCytonBase; 
    vTotal{end+1} = vCytonBase;
    fTotal{end+1} = fRobotBase; 
    vTotal{end+1} = vRobotBase;